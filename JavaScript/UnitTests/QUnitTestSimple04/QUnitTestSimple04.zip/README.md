QUnitTestSimple04
-----------------

Basic unit test example with support:

- QUnit
- Karma
- Grunt
- JsHint
